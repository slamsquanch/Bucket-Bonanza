/**
 * Created by Zac on 2016-05-09.
 */

function bucketControls() {
    var bucketLeft = document.createElement("IMG");
    var bucketRight = document.createElement("IMG");
    var bucketMid = document.createElement("IMG");

    /* Makes the left lane button/bucket placeholder*/
    bucketLeft.setAttribute("src", "graphics/invisible_bucket.png");
    /*bucketLeft.setAttribute("width", "20%");
     bucketLeft.setAttribute("height", "20%");*/
    bucketLeft.setAttribute("alt", "Transparent button-left");
    bucketLeft.setAttribute("id", "LeftPlace");
    bucketLeft.style.position = "absolute";
    bucketLeft.style.marginLeft = "15%"
    bucketLeft.style.marginTop = "500px";
    document.body.appendChild(bucketLeft);

    /* Makes the right lane button/bucket placeholder*/
    bucketRight.setAttribute("src", "graphics/invisible_bucket.png");
    /*bucketRight.setAttribute("width", "20%");
     bucketRight.setAttribute("height", "20%");*/
    bucketRight.setAttribute("alt", "Transparent button-right");
    bucketRight.setAttribute("id", "RightPlace");
    bucketRight.style.position = "absolute";
    bucketRight.style.marginLeft = "45%";
    bucketRight.style.marginTop = "500px";
    document.body.appendChild(bucketRight);

    /* Makes the Middle lane button/bucket placeholder*/
    bucketMid.setAttribute("src", "graphics/Bucket.png");
    /*bucketMid.setAttribute("width", "20%");
     bucketMid.setAttribute("height", "20%");*/
    bucketMid.setAttribute("alt", "Transparent button-mid");
    bucketMid.setAttribute("id", "MidPlace");
    bucketMid.style.position = "absolute";
    bucketMid.style.marginLeft = "30%";
    bucketMid.style.marginTop = "500px";
    document.body.appendChild(bucketMid);

    /* Left lane click */
    bucketLeft.onclick=function() {
        this.src="graphics/Bucket.png";
        bucketRight.src="graphics/invisible_bucket.png";
        bucketMid.src="graphics/invisible_bucket.png";
    }

    /* Right lane click */
    bucketRight.onclick=function() {
        this.src="graphics/Bucket.png";
        bucketLeft.src="graphics/invisible_bucket.png";
        bucketMid.src="graphics/invisible_bucket.png";
    }

    /* Middle lane click */
    bucketMid.onclick=function() {
        this.src="graphics/Bucket.png";
        bucketLeft.src="graphics/invisible_bucket.png";
        bucketRight.src="graphics/invisible_bucket.png";
    }
}

/******************************************/
/*** RANDOMLY DROPPING SHAPES CODE HERE ***/
/******************************************/

function Object(imgSrc, element, timer){
    this.imgSrc =imgSrc;
    this.element= element;
    this.myTimer = timer;
}

//returns a random src name
function randomObject(){
    var scrNames = new Array("graphics/blueCircle.png", "graphics/blueSquare.png",
        "graphics/blueTriangle.png", "graphics/redCircle.png", "graphics/redSquare.png", "graphics/redTriangle.png",
        "graphics/yellowCircle.png", "graphics/yellowSquare.png", "graphics/yellowTriangle.png");
    // if you wish to change the max and min for the random generator
    // change the 8 for max and the 0 for min.
    var randomNum = Math.floor((Math.random() * 8) + 0);
    return scrNames[randomNum];
}

function randomLane(){
    var lanes = ["15%", "30%", "45%"];
    return lanes[Math.floor(Math.random() * 3)];
}

function createObject(){
    var imgSrc = randomObject();
    var element = document.createElement("img")
    /*element.setAttribute("width", "8%");
     element.setAttribute("height", "8%");*/
    element.style = "position:absolute; top:1px";
    element.style.marginLeft = randomLane();
    element.src = imgSrc;
    element.className = "fallingObject";
    var coolObject = new Object(imgSrc, element, null);
    document.body.appendChild(coolObject.element);
    return coolObject;
}

function move(){

    var objectArray = document.querySelectorAll(".fallingObject");
    for(var i = 0; i < objectArray.length; i++){
        objectArray[i].style.top = parseInt(objectArray[i].style.top) + 1 + "px";
    }
}
function checkLimits(){
    var objectArray = document.querySelectorAll(".fallingObject");
    for(var i = 0; i < objectArray.length; i++){
        if(parseInt(objectArray[i].style.top) > 500){
            objectArray[i].parentNode.removeChild(objectArray[i]);
        }
    }
}

/*******************************/
/****** ONLOAD FUNCTION  *******/
/*******************************/
onload= function(){
    bucketControls();
    var objectTimer = setInterval('createObject();', 1500);
    //var randomObject = createObject();
    //	var object = document.querySelector('.fallingObject');
    var timer = setInterval('move();', 2);
    var limitTimer = setInterval('checkLimits();', 1);
    //object instead of window will require you to click on the circle itself
    /*window.onclick=function(){
     if(timer == null){
     timer = setInterval('move();', 2);
     objectTimer = setInterval('createObject();', 1000);
     }
     else{
     clearInterval(timer);
     timer = null;
     clearInterval(objectTimer);
     objectTimer = null;
     }

     };*/
}







